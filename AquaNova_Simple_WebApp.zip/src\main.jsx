import { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const defaultProducts = [
  {
    id: 'betta-red',
    name: 'Red Betta',
    category: 'Fish',
    price: 320,
    size: '2.5 in',
    availability: 'In stock',
    image: 'https://images.unsplash.com/photo-1544551763-46a013bb70b5?auto=format&fit=crop&w=900&q=80',
    description: 'Bright color and easy temperament for beginner aquariums.',
  },
  {
    id: 'guppy-spark',
    name: 'Spark Guppy',
    category: 'Fish',
    price: 180,
    size: '1.5 in',
    availability: 'Limited',
    image: 'https://images.unsplash.com/photo-1522069169874-c58ec4b76be5?auto=format&fit=crop&w=900&q=80',
    description: 'Colorful community fish for planted and active tanks.',
  },
  {
    id: 'goldfish-oranda',
    name: 'Oranda Goldfish',
    category: 'Fish',
    price: 450,
    size: '4 in',
    availability: 'Ask to confirm',
    image: 'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?auto=format&fit=crop&w=900&q=80',
    description: 'A favorite for calm, spacious home aquariums.',
  },
  {
    id: 'aquarium-30g',
    name: '30-Gallon Aquarium',
    category: 'Aquariums',
    price: 6800,
    size: '30 gal',
    availability: 'Available',
    image: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=900&q=80',
    description: 'A clean setup for new hobbyists and small collections.',
  },
  {
    id: 'aquarium-60g',
    name: '60-Gallon Aquarium',
    category: 'Aquariums',
    price: 12700,
    size: '60 gal',
    availability: 'Ask to confirm',
    image: 'https://images.unsplash.com/photo-1535591273668-578e31182c4f?auto=format&fit=crop&w=900&q=80',
    description: 'Perfect for larger fish displays and premium layouts.',
  },
  {
    id: 'filter-kit',
    name: 'Starter Filter Kit',
    category: 'Accessories',
    price: 960,
    size: 'Standard',
    availability: 'In stock',
    image: 'https://images.unsplash.com/photo-1570288686795-53f8d4b0d4d5?auto=format&fit=crop&w=900&q=80',
    description: 'Simple filtration and maintenance essentials for healthy tanks.',
  },
];

const categories = ['All', 'Fish', 'Aquariums', 'Accessories'];
const formatCurrency = (amount) =>
  new Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency: 'PHP',
    maximumFractionDigits: 0,
  }).format(amount);

function App() {
  const [products, setProducts] = useState(defaultProducts);
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [cartOpen, setCartOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('aquanova-user') || 'null');
    } catch {
      return null;
    }
  });
  const [cart, setCart] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('aquanova-cart') || '[]');
    } catch {
      return [];
    }
  });
  const [authForm, setAuthForm] = useState({ name: '', email: '', password: '' });
  const [checkoutForm, setCheckoutForm] = useState({ name: '', phone: '', email: '', address: '' });
  const [notice, setNotice] = useState('');

  useEffect(() => {
    fetch('/api/products.php')
      .then((response) => response.json())
      .then((data) => {
        if (Array.isArray(data.products) && data.products.length) {
          setProducts(data.products);
        }
      })
      .catch(() => {
        setProducts(defaultProducts);
      });
  }, []);

  useEffect(() => {
    localStorage.setItem('aquanova-cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('aquanova-user', JSON.stringify(user));
    } else {
      localStorage.removeItem('aquanova-user');
    }
  }, [user]);

  const filteredProducts = useMemo(() => {
    const term = query.toLowerCase();

    return products.filter((product) => {
      const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
      const searchable = [product.name, product.category, product.size, product.description]
        .join(' ')
        .toLowerCase();
      const matchesQuery = !term || searchable.includes(term);
      return matchesCategory && matchesQuery;
    });
  }, [products, query, selectedCategory]);

  const cartItems = useMemo(() => {
    return cart
      .map((entry) => {
        const product = products.find((item) => item.id === entry.id);
        if (!product) return null;
        return { ...product, qty: entry.qty };
      })
      .filter(Boolean);
  }, [cart, products]);

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);

  const addToCart = (product) => {
    if (!user) {
      setAuthMode('login');
      setAuthOpen(true);
      setNotice('Please log in before placing an order.');
      return;
    }

    setCart((current) => {
      const existing = current.find((entry) => entry.id === product.id);
      if (existing) {
        return current.map((entry) =>
          entry.id === product.id ? { ...entry, qty: entry.qty + 1 } : entry,
        );
      }
      return [...current, { id: product.id, qty: 1 }];
    });
    setCartOpen(true);
  };

  const updateQty = (id, delta) => {
    setCart((current) =>
      current
        .map((entry) => (entry.id === id ? { ...entry, qty: Math.max(0, entry.qty + delta) } : entry))
        .filter((entry) => entry.qty > 0),
    );
  };

  const handleAuthSubmit = (event) => {
    event.preventDefault();
    const email = authForm.email.trim();
    const name = authForm.name.trim() || 'Customer';

    if (!email || !authForm.password.trim()) {
      setNotice('Email and password are required.');
      return;
    }

    setUser({ name, email });
    setAuthForm({ name: '', email: '', password: '' });
    setAuthOpen(false);
    setNotice(authMode === 'signup' ? 'Account created successfully.' : 'Welcome back.');
  };

  const handleCheckout = async (event) => {
    event.preventDefault();

    if (!user) {
      setAuthMode('login');
      setAuthOpen(true);
      setNotice('You need an account before checkout.');
      return;
    }

    if (!cartItems.length) {
      setNotice('Your cart is empty.');
      return;
    }

    try {
      const response = await fetch('/api/checkout.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer: {
            name: checkoutForm.name || user.name,
            phone: checkoutForm.phone,
            email: checkoutForm.email || user.email,
            address: checkoutForm.address,
          },
          items: cartItems.map(({ id, qty, price }) => ({ id, qty, price })),
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.message || 'Checkout failed.');
      }

      setCheckoutOpen(false);
      setCheckoutForm({ name: '', phone: '', email: '', address: '' });
      setCart([]);
      setNotice(`Order ${data.order_id} placed successfully.`);
    } catch (error) {
      setNotice(error.message || 'Checkout failed. Please try again.');
    }
  };

  return (
    <div className="page-shell">
      <header className="topbar">
        <div className="container topbar-inner">
          <div className="brand-wrap">
            <div className="brand-badge">A</div>
            <div>
              <div className="brand-title">AQUANOVA</div>
              <div className="brand-subtitle">Aquatica Nasugbu</div>
            </div>
          </div>

          <nav className="main-nav" aria-label="Main navigation">
            <a href="#home">Home</a>
            <a href="#catalog">Shop</a>
            <a href="#story">About</a>
            <a href="#process">How it works</a>
            <a href="#contact">Contact</a>
          </nav>

          <div className="topbar-actions">
            {user ? (
              <button type="button" className="link-button" onClick={() => setUser(null)}>
                Log out
              </button>
            ) : (
              <button type="button" className="link-button" onClick={() => setAuthOpen(true)}>
                Sign in
              </button>
            )}
            <button type="button" className="cart-button" onClick={() => setCartOpen(true)}>
              Cart <span>{cartItems.reduce((sum, item) => sum + item.qty, 0)}</span>
            </button>
          </div>
        </div>
      </header>

      <main>
        <section id="home" className="hero container">
          <div className="hero-copy">
            <p className="eyebrow">Ornamental fish and aquariums</p>
            <h1>Modern aquatics for homes, hobbyists, and first-time fish keepers.</h1>
            <p>
              Aquatica Nasugbu brings together healthy fish, clean aquarium setups, and a simple buying
              experience designed for people who want the right setup without the extra confusion.
            </p>
            <div className="cta-row">
              <a href="#catalog" className="btn btn-black">Shop now</a>
              <button type="button" className="btn btn-light" onClick={() => setCheckoutOpen(true)}>
                View cart
              </button>
            </div>
            <div className="hero-metrics">
              <div>
                <strong>Fresh arrivals</strong>
                <span>Updated weekly</span>
              </div>
              <div>
                <strong>Local pickup</strong>
                <span>Since 2018</span>
              </div>
              <div>
                <strong>Client help</strong>
                <span>Care advice included</span>
              </div>
            </div>
          </div>

          <div className="hero-visual">
            <img
              src="https://images.unsplash.com/photo-1544551763-46a013bb70b5?auto=format&fit=crop&w=1200&q=80"
              alt="Aquatic fish and aquarium display"
            />
          </div>
        </section>

        <section className="container section-block">
          <div className="section-heading">
            <p className="eyebrow">Top categories</p>
            <h2>Browse by setup</h2>
          </div>

          <div className="category-grid">
            <article className="mini-card dark-card">
              <span>01</span>
              <h3>Freshwater fish</h3>
              <p>Healthy and colorful options for beginner and experienced hobbyists.</p>
            </article>
            <article className="mini-card">
              <span>02</span>
              <h3>Aquarium tanks</h3>
              <p>Simple, reliable sizes for homes, offices, and display spaces.</p>
            </article>
            <article className="mini-card">
              <span>03</span>
              <h3>Accessories</h3>
              <p>Filtration, lighting, and starter gear for cleaner fish care.</p>
            </article>
          </div>
        </section>

        <section id="catalog" className="container section-block catalog-section">
          <div className="section-heading split-heading">
            <div>
              <p className="eyebrow">Shop catalog</p>
              <h2>Popular products</h2>
            </div>
            <div className="catalog-tools">
              <input
                type="search"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search fish or equipment"
              />
              <div className="filter-row">
                {categories.map((category) => (
                  <button
                    key={category}
                    type="button"
                    className={selectedCategory === category ? 'filter-pill active' : 'filter-pill'}
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="product-grid">
            {filteredProducts.map((product) => (
              <article key={product.id} className="product-card">
                <div className="product-image-wrap">
                  <img src={product.image} alt={product.name} />
                </div>
                <div className="product-content">
                  <div className="product-head">
                    <span className="category-tag">{product.category}</span>
                    <span className="availability">{product.availability}</span>
                  </div>
                  <h3>{product.name}</h3>
                  <p className="meta">{product.size}</p>
                  <p className="description">{product.description}</p>
                  <div className="price-row">
                    <strong>{formatCurrency(product.price)}</strong>
                    <button type="button" className="btn btn-black small" onClick={() => addToCart(product)}>
                      Add to cart
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section id="story" className="story-wrap section-block">
          <div className="container story-grid">
            <div className="story-photo">
              <img
                src="https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?auto=format&fit=crop&w=1200&q=80"
                alt="A healthy aquarium display"
              />
            </div>
            <div className="story-copy">
              <p className="eyebrow">Why customers trust us</p>
              <h2>Simple care, honest stock, and no pressure buying.</h2>
              <p>
                We help buyers choose the right fish and setup based on their space, budget, and experience.
                Every listing is meant to feel clear, useful, and honest before a customer even steps into the
                shop.
              </p>
              <ul>
                <li>Practical guidance for beginners</li>
                <li>Clear stock updates and real availability notes</li>
                <li>Local pickup and direct messaging options</li>
              </ul>
            </div>
          </div>
        </section>

        <section id="process" className="container section-block">
          <div className="section-heading">
            <p className="eyebrow">How it works</p>
            <h2>Customer journey</h2>
          </div>
          <div className="steps-grid">
            <div className="step-card">
              <span>01</span>
              <h3>Browse</h3>
              <p>Search fish, tanks, and accessories by category and price.</p>
            </div>
            <div className="step-card">
              <span>02</span>
              <h3>Sign in</h3>
              <p>Register or log in before purchase to continue securely.</p>
            </div>
            <div className="step-card">
              <span>03</span>
              <h3>Add to cart</h3>
              <p>Choose quantity, confirm details, and prepare your order.</p>
            </div>
            <div className="step-card">
              <span>04</span>
              <h3>Checkout</h3>
              <p>Submit buyer information and place the order for processing.</p>
            </div>
          </div>
        </section>

        <section id="contact" className="container section-block contact-block">
          <div className="contact-copy">
            <p className="eyebrow">Visit or message</p>
            <h2>Ask about tank setup or fish availability.</h2>
            <p>
              We respond quickly for product questions, local pickup, and custom recommendations for new aquariums.
            </p>
            <ul>
              <li>Phone: (043) 123-4567</li>
              <li>Address: 123 Seaside Avenue, Nasugbu, Batangas</li>
              <li>Facebook: Aquatica Nasugbu</li>
            </ul>
          </div>
          <form className="contact-form" onSubmit={(event) => event.preventDefault()}>
            <input type="text" placeholder="Your name" />
            <input type="email" placeholder="Email" />
            <input type="text" placeholder="Product or concern" />
            <textarea rows="5" placeholder="Message" />
            <button type="submit" className="btn btn-black">Send inquiry</button>
          </form>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container footer-grid">
          <div>
            <div className="brand-title white">AQUANOVA</div>
            <p>Fish and aquarium essentials for modern homes and hobbyists.</p>
          </div>
          <div>
            <h4>Quick links</h4>
            <a href="#catalog">Shop</a>
            <a href="#story">About</a>
            <a href="#process">How it works</a>
          </div>
          <div>
            <h4>Visit</h4>
            <p>123 Seaside Avenue</p>
            <p>Nasugbu, Batangas</p>
          </div>
          <div>
            <h4>Contact</h4>
            <p>(043) 123-4567</p>
            <p>hello@aquatica.com</p>
          </div>
        </div>
      </footer>

      {cartOpen && (
        <aside className="drawer">
          <div className="drawer-header">
            <h3>Your cart</h3>
            <button type="button" className="close-btn" onClick={() => setCartOpen(false)}>
              ×
            </button>
          </div>

          {cartItems.length === 0 ? (
            <div className="empty-state">Your cart is empty.</div>
          ) : (
            <>
              <div className="cart-list">
                {cartItems.map((item) => (
                  <div key={item.id} className="cart-item">
                    <div>
                      <strong>{item.name}</strong>
                      <span>{formatCurrency(item.price)}</span>
                    </div>
                    <div className="cart-qty">
                      <button type="button" onClick={() => updateQty(item.id, -1)}>-</button>
                      <span>{item.qty}</span>
                      <button type="button" onClick={() => updateQty(item.id, 1)}>+</button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="cart-footer">
                <div className="totals">
                  <span>Subtotal</span>
                  <strong>{formatCurrency(subtotal)}</strong>
                </div>
                <button type="button" className="btn btn-black" onClick={() => setCheckoutOpen(true)}>
                  Proceed to checkout
                </button>
              </div>
            </>
          )}
        </aside>
      )}

      {authOpen && (
        <div className="modal-backdrop" onClick={() => setAuthOpen(false)}>
          <div className="auth-panel" onClick={(event) => event.stopPropagation()}>
            <div className="drawer-header">
              <h3>{authMode === 'login' ? 'Log in' : 'Create account'}</h3>
              <button type="button" className="close-btn" onClick={() => setAuthOpen(false)}>
                ×
              </button>
            </div>

            <form onSubmit={handleAuthSubmit} className="auth-form">
              {authMode === 'signup' && (
                <input
                  type="text"
                  value={authForm.name}
                  onChange={(event) => setAuthForm({ ...authForm, name: event.target.value })}
                  placeholder="Full name"
                />
              )}
              <input
                type="email"
                value={authForm.email}
                onChange={(event) => setAuthForm({ ...authForm, email: event.target.value })}
                placeholder="Email address"
              />
              <input
                type="password"
                value={authForm.password}
                onChange={(event) => setAuthForm({ ...authForm, password: event.target.value })}
                placeholder="Password"
              />
              <button type="submit" className="btn btn-black">
                {authMode === 'login' ? 'Continue' : 'Create account'}
              </button>
            </form>

            <button type="button" className="switch-link" onClick={() => setAuthMode(authMode === 'login' ? 'signup' : 'login')}>
              {authMode === 'login' ? 'Need an account? Sign up' : 'Already have an account? Log in'}
            </button>
            {notice && <p className="notice">{notice}</p>}
          </div>
        </div>
      )}

      {checkoutOpen && (
        <div className="modal-backdrop" onClick={() => setCheckoutOpen(false)}>
          <div className="checkout-panel" onClick={(event) => event.stopPropagation()}>
            <div className="drawer-header">
              <h3>Checkout</h3>
              <button type="button" className="close-btn" onClick={() => setCheckoutOpen(false)}>
                ×
              </button>
            </div>

            <form className="checkout-form" onSubmit={handleCheckout}>
              <input
                type="text"
                value={checkoutForm.name}
                onChange={(event) => setCheckoutForm({ ...checkoutForm, name: event.target.value })}
                placeholder="Full name"
                required
              />
              <input
                type="tel"
                value={checkoutForm.phone}
                onChange={(event) => setCheckoutForm({ ...checkoutForm, phone: event.target.value })}
                placeholder="Phone number"
                required
              />
              <input
                type="email"
                value={checkoutForm.email}
                onChange={(event) => setCheckoutForm({ ...checkoutForm, email: event.target.value })}
                placeholder="Email"
                required
              />
              <textarea
                rows="4"
                value={checkoutForm.address}
                onChange={(event) => setCheckoutForm({ ...checkoutForm, address: event.target.value })}
                placeholder="Delivery or pickup address"
                required
              />

              <div className="totals">
                <span>Total</span>
                <strong>{formatCurrency(subtotal)}</strong>
              </div>

              <button type="submit" className="btn btn-black">
                Place order
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);