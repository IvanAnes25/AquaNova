<?php

declare(strict_types=1);

return array (
  'environment' => 'local',
  'app_url' => 'http://localhost/AquaNova',
  'app_key' => 'ebc14cfdc384afef5c43870e9b69504ebf8c3abbf5c8c641e27e6951093cec69',
  'trust_proxy_https' => false,
  'database' => 
  array (
    'host' => '127.0.0.1',
    'port' => 3306,
    'name' => 'aquanova',
    'username' => 'root',
    'password' => '',
  ),
  'argon2' => 
  array (
    'memory_cost' => 32768,
    'time_cost' => 3,
    'threads' => 1,
  ),
  'dummy_password_hash' => '$argon2id$v=19$m=32768,t=3,p=1$VVRmUExpelR2NEtYNWF0dA$Lb1NZ7TcEyTKsdCqQ2Ta1teil/hkXQvGwLGMgDa7YEc',
  'mail' => 
  array (
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'username' => '24-72743@g.batstate-u.edu.ph',
    'password' => 'ikqehjvkdfyyfzyd',
    'encryption' => 'tls',
    'from_email' => '24-72743@g.batstate-u.edu.ph',
    'from_name' => 'Nasugbu Aquatica',
  ),
);
