import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './styles/about.css';
import './styles/style.css';

createRoot(document.getElementById('root')).render(<App />);
