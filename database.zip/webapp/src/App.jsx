import { useEffect, useMemo, useState } from 'react';
import Icon from './Icon.jsx';
import Sidebar, { customerPages, ownerPages } from './components/Sidebar.jsx';
import { Button, Field, Modal } from './components/UI.jsx';
import { money } from './lib/format.js';
import { orderNeedsAction } from './data.js';
import { authGet, authPost } from './lib/authApi.js';
import { commerceGet, commerceGetAll, commerceRequest } from './lib/commerceApi.js';
import { commercePath } from './lib/commerceApi.js';
import AccountPage from './pages/AccountPage.jsx';
import CartPage from './pages/CartPage.jsx';
import CheckoutPage from './pages/CheckoutPage.jsx';
import CustomersPage from './pages/CustomersPage.jsx';
import DashboardPage from './pages/DashboardPage.jsx';
import HomePage from './pages/HomePage.jsx';
import InventoryPage from './pages/InventoryPage.jsx';
import MyOrdersPage from './pages/MyOrdersPage.jsx';
import NotificationsPage from './pages/NotificationsPage.jsx';
import OrderDetailPage from './pages/OrderDetailPage.jsx';
import OrdersPage from './pages/OrdersPage.jsx';
import PaymentPage from './pages/PaymentPage.jsx';
import ProductsPage from './pages/ProductsPage.jsx';
import ReportsPage from './pages/ReportsPage.jsx';
import SettingsPage from './pages/SettingsPage.jsx';
import ShopPage from './pages/ShopPage.jsx';
import FirstLoginPasswordPage from './pages/FirstLoginPasswordPage.jsx';
import { ProductImage } from './components/ProductGrid.jsx';

const pageTitles = {
  home: 'A little piece of the ocean', shop: 'Shop', cart: 'Your cart', checkout: 'Checkout',
  'my-orders': 'My orders', account: 'My account', dashboard: 'Dashboard', orders: 'Orders',
  products: 'Products', inventory: 'Inventory', customers: 'Customers',
  reports: 'Reports', settings: 'Settings', notifications: 'Notifications', payment: 'Pay with GCash', 'order-placed': 'Order placed',
  'proof-submitted': 'Payment received', 'order-detail': 'Order details',
};
function websiteLoginPath() {
  const projectBase = window.location.pathname.replace(/\/webapp\/?$/, '').replace(/\/+$/, '');
  return `${projectBase}/login`;
}

function stored(key, fallback) {
  const saved = localStorage.getItem(key);
  return saved ? JSON.parse(saved) : fallback;
}

export default function App() {
  const [page, setPage] = useState('login');
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);
  const [sessionLoading, setSessionLoading] = useState(true);
  const [accessLoading, setAccessLoading] = useState(false);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [cart, setCart] = useState([]);
  const [movements, setMovements] = useState([]);
  const [settings, setSettings] = useState({ deliveryFee: 0, gcashReady: false });
  const [report, setReport] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [modal, setModal] = useState(null);
  const [toast, setToast] = useState('');
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [activeOrderId, setActiveOrderId] = useState(null);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All items');
  const [orderFilter, setOrderFilter] = useState('Needs action');
  const [deliveryMethod, setDeliveryMethod] = useState('Delivery');
  const [paymentMethod, setPaymentMethod] = useState('GCash');
  const [customer, setCustomer] = useState({ name: '', phone: '', email: '', address: '', notes: '' });
  const [proofRef, setProofRef] = useState('');
  const [proofFile, setProofFile] = useState(null);
  const [proofError, setProofError] = useState('');
  const [proofOrderId, setProofOrderId] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [cancelReason, setCancelReason] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [productForm, setProductForm] = useState({ name: '', category: 'Fish', price: '', stock: '', size: '', description: '' });
  const [stockForm, setStockForm] = useState({ productId: '', quantity: '', reason: 'Restock', note: '' });

  useEffect(() => {
    let active = true;
    async function restoreSession() {
      try {
        const session = await authGet('/api/auth/session.php');
        if (!active) return;
        if (!session.user) {
          window.location.replace(websiteLoginPath());
          return;
        }
        if (session.user.mustChangePassword) {
          setUser(session.user);
          setRole(session.user.role);
          setSessionLoading(false);
          return;
        }
        const verified = await verifyRole(session.user.role);
        if (!active) return;
        setUser(verified);
        setRole(verified.role);
        setPage(verified.role === 'owner' ? 'dashboard' : 'home');
        await reloadWorkspace(verified.role);
      } catch {
        if (active) window.location.replace(websiteLoginPath());
      } finally {
        if (active) setSessionLoading(false);
      }
    }
    restoreSession();
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!toast) return undefined;
    const timer = window.setTimeout(() => setToast(''), 3200);
    return () => window.clearTimeout(timer);
  }, [toast]);
  useEffect(() => {
    if (!role || !['shop', 'products'].includes(page)) return undefined;
    const timer = window.setTimeout(async () => {
      try {
        const params = new URLSearchParams();
        if (query.trim()) params.set('q', query.trim());
        if (category !== 'All items') params.set('category', category);
        const catalogPath = role === 'owner' ? '/owner/products' : '/catalog/products';
        const result = await commerceGetAll(`${catalogPath}?${params.toString()}`, ['products']);
        setProducts(result.products);
      } catch (error) {
        setToast(error.message);
      }
    }, 250);
    return () => window.clearTimeout(timer);
  }, [category, page, query, role]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const fee = deliveryMethod === 'Delivery' ? Number(settings.deliveryFee || 0) : 0;
  const total = subtotal + fee;
  const activeOrder = orders.find((order) => order.id === activeOrderId) || null;
  const paymentOrder = orders.find((order) => order.id === proofOrderId) || null;
  const filteredProducts = useMemo(() => products.filter((product) => {
    const categoryMatches = category === 'All items' || product.category === category;
    return categoryMatches && `${product.name} ${product.category}`.toLowerCase().includes(query.toLowerCase());
  }), [category, products, query]);
  const notify = (message) => setToast(message);
  async function reloadWorkspace(currentRole = role) {
    if (currentRole === 'customer') {
      const [catalog, cartData, orderData, profileData, shopSettings, notificationData, notificationCount] = await Promise.all([
        commerceGetAll('/catalog/products', ['products']),
        commerceGetAll('/cart', ['items']),
        commerceGetAll('/orders', ['orders']),
        commerceGet('/account/profile'),
        commerceGet('/settings/public'),
        commerceGetAll('/notifications', ['notifications']),
        commerceGet('/notifications/unread-count'),
      ]);
      setProducts(catalog.products);
      setCart(cartData.items.map((item) => ({ productId: item.id, name: item.name, price: item.price, quantity: item.quantity })));
      setOrders(orderData.orders);
      setCustomer(profileData.profile);
      setSettings(shopSettings);
      setNotifications(notificationData.notifications);
      setUnreadNotifications(notificationCount.count);
      return;
    }
    if (currentRole === 'owner') {
      const [catalog, inventory, orderData, settingsData, customerData, reportData, notificationData, notificationCount] = await Promise.all([
        commerceGetAll('/owner/products', ['products']),
        commerceGetAll('/owner/inventory', [
          { key: 'products', pageKey: 'productsPage', sizeKey: 'productsPageSize', metaKey: 'productsPagination' },
          { key: 'movements', pageKey: 'movementsPage', sizeKey: 'movementsPageSize', metaKey: 'movementsPagination' },
        ]),
        commerceGetAll('/owner/orders', ['orders']),
        commerceGet('/owner/settings'),
        commerceGetAll('/owner/customers', ['customers']),
        commerceGet('/owner/reports'),
        commerceGetAll('/notifications', ['notifications']),
        commerceGet('/notifications/unread-count'),
      ]);
      setProducts(catalog.products);
      setMovements(inventory.movements);
      setOrders(orderData.orders);
      setSettings(settingsData.settings);
      setCustomers(customerData.customers);
      setReport(reportData);
      setNotifications(notificationData.notifications);
      setUnreadNotifications(notificationCount.count);
    }
  }
  const verifyRole = async (requiredRole) => {
    if (!['customer', 'owner'].includes(requiredRole)) {
      throw new Error('This account does not have an app role.');
    }
    const endpoint = requiredRole === 'owner' ? '/api/auth/owner-page.php' : '/api/auth/customer-page.php';
    const result = await authGet(endpoint);
    if (result.user?.role !== requiredRole) {
      throw new Error('Your account does not have access to this area.');
    }
    return result.user;
  };
  const clearSession = () => {
    setUser(null);
    setRole(null);
    setModal(null);
    window.location.replace(websiteLoginPath());
  };
  const navigate = async (nextPage) => {
    const requiredRole = ownerPages.includes(nextPage)
      ? 'owner'
      : [...customerPages, 'checkout', 'payment', 'order-detail', 'order-placed', 'proof-submitted'].includes(nextPage)
        ? 'customer'
        : null;
    if (!role || !user) {
      setPage('login');
      return;
    }
    if (requiredRole && role !== requiredRole) {
      notify('This area is not available for your account.');
      return;
    }
    setAccessLoading(true);
    try {
      if (requiredRole) {
        const verified = await verifyRole(requiredRole);
        setUser(verified);
      }
      setPage(nextPage);
      setQuery('');
      setMobileMenu(false);
      setSelectedProduct(null);
    } catch (error) {
      clearSession(error.message);
    } finally {
      setAccessLoading(false);
    }
  };
  const runOwnerAction = async (action) => {
    try {
      await verifyRole('owner');
      await action();
    } catch (error) {
      notify(error.message);
    }
  };
  const cancelOrder = async (order, reason = 'Cancelled by customer') => {
    try {
      if (role === 'owner') {
        await commerceRequest(`/owner/orders/${order.databaseId}/actions`, 'POST', { action: 'cancel', reason });
        await reloadWorkspace('owner');
      } else {
        await commerceRequest(`/orders/${order.databaseId}/cancel`, 'POST', { reason });
        await reloadWorkspace('customer');
      }
      setModal(null);
      setCancelReason('');
      notify(`${order.id} has been cancelled.`);
    } catch (error) {
      notify(error.message);
    }
  };
  const addToCart = async (product, quantity = 1) => {
    try {
      await commerceRequest('/cart/items', 'POST', { productId: product.id, quantity });
      await reloadWorkspace('customer');
      notify(`${product.name} added to cart.`);
    } catch (error) {
      notify(error.message);
    }
  };
  const changeCartQty = async (productId, amount) => {
    const item = cart.find((line) => line.productId === productId);
    if (!item) return;
    try {
      await commerceRequest(`/cart/items/${encodeURIComponent(productId)}`, 'PATCH', { quantity: Math.max(0, item.quantity + amount) });
      await reloadWorkspace('customer');
    } catch (error) {
      notify(error.message);
    }
  };
  const placeOrder = async (method) => {
    const paymentMethod = method === 'GCash' ? 'gcash' : method === 'Cash on delivery' ? 'cod' : 'cash_pickup';
    try {
      const result = await commerceRequest('/orders', 'POST', {
        fulfillment: deliveryMethod === 'Delivery' ? 'delivery' : 'pickup',
        paymentMethod,
        name: customer.name,
        phone: customer.phone,
        address: customer.address,
        notes: customer.notes,
      });
      await reloadWorkspace('customer');
      setActiveOrderId(result.order.id);
      if (paymentMethod === 'gcash') {
        setProofOrderId(result.order.id);
        setProofRef('');
        setProofFile(null);
        setProofError('');
        setPage('payment');
      } else {
        setPage('order-placed');
      }
    } catch (error) {
      notify(error.message);
    }
  };
  const submitProof = async (orderId) => {
    const order = orders.find((item) => item.id === orderId);
    if (!order || order.status !== 'Pending' || !['Unpaid', 'Rejected'].includes(order.paymentStatus)) {
      setProofError('This order is not accepting payment proof right now.');
      return;
    }
    const reference = proofRef.trim();
    if (!/^[a-zA-Z0-9]{6,20}$/.test(reference)) {
      setProofError('Enter a valid GCash reference number (6–20 letters or numbers).');
      return;
    }
    if (!proofFile) {
      setProofError('Upload a screenshot of your GCash payment.');
      return;
    }
    try {
      const form = new FormData();
      form.append('reference', reference);
      form.append('proof', proofFile);
      await commerceRequest(`/orders/${order.databaseId}/payment-proof`, 'POST', form);
      await reloadWorkspace('customer');
      setProofError('');
      setPage('proof-submitted');
      notify('Payment proof submitted for review.');
    } catch (error) {
      setProofError(error.message);
    }
  };
  const chooseProof = (file) => {
    if (!file) return;
    if (file.size < 1) {
      setProofError('This image is empty. Choose another file.');
      setProofFile(null);
    } else if (file.size > 2 * 1024 * 1024) {
      setProofError('This image is over 2 MB. Choose a smaller file.');
      setProofFile(null);
    } else {
      setProofFile(file);
      setProofError('');
    }
  };
  const ownerOrderAction = async (order, action, values = {}) => {
    await commerceRequest(`/owner/orders/${order.databaseId}/actions`, 'POST', { action, ...values });
    await reloadWorkspace('owner');
    setModal(null);
    setRejectReason('');
    setCancelReason('');
    notify(`Order ${order.id} updated.`);
  };
  const approvePayment = (order) => ownerOrderAction(order, 'approve_proof');
  const rejectPayment = (order) => ownerOrderAction(order, 'reject_proof', { reason: rejectReason.trim() });
  const confirmOrder = (order) => ownerOrderAction(order, 'confirm_cash');
  const markOrderReady = (order, deliveryBy) => ownerOrderAction(order, 'mark_ready', { deliveryBy });
  const completeOrder = (order) => ownerOrderAction(order, 'complete');
  const saveProduct = async (event) => {
    event.preventDefault();
    const result = await commerceRequest('/owner/products', 'POST', {
      name: productForm.name.trim(), category: productForm.category,
      price: Number(productForm.price), stock: Number(productForm.stock),
      description: productForm.description || 'Freshly stocked at Aquatica Nasugbu.',
    });
    await reloadWorkspace('owner');
    setModal(null);
    setProductForm({ name: '', category: 'Fish', price: '', stock: '', size: '', description: '' });
    notify('Product added to your catalog.');
  };
  const saveStock = async (event) => {
    event.preventDefault();
    const amount = Number(stockForm.quantity);
    const product = products.find((item) => item.id === stockForm.productId);
    if (!product || !Number.isInteger(amount) || amount <= 0) {
      notify('Choose a product and enter a whole-number quantity greater than zero.');
      return;
    }
    await commerceRequest('/owner/inventory/movements', 'POST', {
      productId: product.id,
      quantity: stockForm.reason === 'Adjustment' ? -amount : amount,
      type: stockForm.reason === 'Adjustment' ? 'adjustment' : 'restock',
      reason: stockForm.reason,
      note: stockForm.note,
    });
    await reloadWorkspace('owner');
    setModal(null);
    notify(`${product.name} stock updated.`);
  };
  const openStockForm = (product, reason = 'Restock') => {
    setStockForm({ productId: product?.id || '', quantity: '', reason, note: '' });
    setModal({ type: 'stock' });
  };
  const chooseOrder = (order) => {
    setActiveOrderId(order.id);
    if (order.method === 'GCash' && ['Unpaid', 'Rejected'].includes(order.paymentStatus)) {
      setProofOrderId(order.id);
      setProofRef('');
      setProofFile(null);
      setProofError('');
      navigate('payment');
    } else {
      navigate('order-detail');
    }
  };
  const copyText = async (value) => {
    try {
      await navigator.clipboard.writeText(value);
      notify(value === '0917 555 0142' ? 'GCash number copied.' : 'Amount copied.');
    } catch {
      notify('Clipboard access is unavailable in this browser.');
    }
  };
  const openOrderModal = (order) => runOwnerAction(() => {
    setActiveOrderId(order.id);
    navigate('orders');
  });
  const openPaymentReview = (order, action) => runOwnerAction(() => {
    if (action === 'reject') {
      setRejectReason('');
      setModal({ type: 'reject', order });
    } else {
      setModal({ type: 'proof', order });
    }
  });
  const logout = async () => {
    try {
      await authPost('/api/auth/logout.php');
      clearSession();
      setCart([]);
      setToast('');
    } catch (error) {
      notify(error.message);
    }
  };
  const pageProps = {
    products, orders, movements, cart, subtotal, fee, total, customer, setCustomer, category, setCategory,
    query, setQuery, orderFilter, setFilter: setOrderFilter, onNavigate: navigate, onProduct: setSelectedProduct,
    onAdd: addToCart, onChangeQty: changeCartQty, onPlaceOrder: placeOrder, deliveryMethod, setDeliveryMethod,
    paymentMethod, setPaymentMethod, checkoutInfo: customer, setCheckoutInfo: setCustomer, onToast: notify,
    settings,
  };
  let content;
  switch (page) {
    case 'home': content = <HomePage {...pageProps} />; break;
    case 'shop': content = <ShopPage {...pageProps} products={filteredProducts} cartCount={cartCount} />; break;
    case 'cart': content = <CartPage {...pageProps} />; break;
    case 'checkout': content = <CheckoutPage {...pageProps} onPlaceOrder={placeOrder} />; break;
    case 'payment': content = <PaymentPage order={paymentOrder} settings={settings} proofRef={proofRef} setProofRef={(value) => { setProofRef(value); setProofError(''); }} proofFile={proofFile} onFile={chooseProof} proofError={proofError} onSubmit={submitProof} onNavigate={navigate} onCopy={copyText} />; break;
    case 'my-orders': content = <MyOrdersPage orders={orders} customerName={customer.name} onNavigate={navigate} onSelect={chooseOrder} />; break;
    case 'order-detail': content = <OrderDetailPage order={activeOrder} onNavigate={navigate} onCancel={(order) => { setCancelReason(''); setModal({ type: 'cancel-customer', order }); }} onNewProof={() => { setProofOrderId(activeOrder.id); setProofRef(''); setProofFile(null); navigate('payment'); }} />; break;
    case 'dashboard': content = <DashboardPage orders={orders} products={products} onNavigate={navigate} onOpenOrder={openOrderModal} />; break;
    case 'orders': content = <OrdersPage
      orders={orders} filter={orderFilter} setFilter={setOrderFilter} query={query} setQuery={setQuery}
      selectedOrderId={activeOrderId} setSelectedOrderId={setActiveOrderId}
      onCheckProof={(order) => openPaymentReview(order, 'preview')}
      onConfirm={(order) => runOwnerAction(() => confirmOrder(order))}
      onMarkReady={(order, deliveryBy) => runOwnerAction(() => markOrderReady(order, deliveryBy))}
      onComplete={(order) => runOwnerAction(() => completeOrder(order))}
      onCancel={(order) => runOwnerAction(() => { setCancelReason(''); setModal({ type: 'cancel', order }); })}
    />; break;
    case 'products': content = <ProductsPage products={products} category={category} setCategory={setCategory} query={query} setQuery={setQuery} onAddProduct={() => runOwnerAction(() => setModal({ type: 'product' }))} onStock={(product) => runOwnerAction(() => openStockForm(product))} />; break;
    case 'inventory': content = <InventoryPage products={products} movements={movements} query={query} setQuery={setQuery} onStock={(product, reason) => runOwnerAction(() => openStockForm(product, reason))} />; break;
    case 'customers': content = <CustomersPage customers={customers} query={query} setQuery={setQuery} onToast={notify} />; break;
    case 'reports': content = <ReportsPage products={products} report={report} onToast={notify} />; break;
    case 'account': content = <AccountPage customer={customer} setCustomer={setCustomer} onSave={async () => { try { await commerceRequest('/account/profile', 'PATCH', customer); await reloadWorkspace('customer'); notify('Profile saved.'); } catch (error) { notify(error.message); } }} onToast={notify} />; break;
    case 'settings': content = <SettingsPage settings={settings} onSave={async (values, qrFile) => { try { await commerceRequest('/owner/settings', 'PATCH', values); if (qrFile) { const form = new FormData(); form.append('qr', qrFile); await commerceRequest('/owner/settings/gcash-qr', 'POST', form); } await reloadWorkspace('owner'); notify('Settings saved.'); } catch (error) { notify(error.message); } }} onToast={notify} />; break;
    case 'notifications': content = <NotificationsPage notifications={notifications} onRead={async (id) => { try { await commerceRequest(`/notifications/${id}/read`, 'PATCH'); await reloadWorkspace(role); } catch (error) { notify(error.message); } }} onReadAll={async () => { try { await commerceRequest('/notifications/read-all', 'POST'); await reloadWorkspace(role); } catch (error) { notify(error.message); } }} />; break;
    case 'order-placed': content = <Confirmation icon="check" title="Order placed!" text={`Thanks, ${customer.name.split(' ')[0] || 'there'}. Your order ${activeOrderId ? `#${activeOrderId}` : ''} is in. We’ll keep you posted as it moves along.`} onOrders={() => navigate('my-orders')} onShop={() => navigate('shop')} />; break;
    case 'proof-submitted': content = <Confirmation icon="clock" title="Payment received for review" text={`We’ve got your GCash proof for order ${proofOrderId}. Our team will check it and update your order soon.`} onOrders={() => navigate('my-orders')} onShop={() => navigate('shop')} />; break;
    default: content = <DashboardPage orders={orders} products={products} onNavigate={navigate} onOpenOrder={openOrderModal} />;
  }
  const pendingCount = orders.filter(orderNeedsAction).length;
  if (sessionLoading) return <main className="auth-loading"><span className="auth-loading-mark">A</span><p>Checking your account…</p></main>;
  if (!user || !role) return <main className="auth-loading"><span className="auth-loading-mark">A</span><p>Redirecting to the website sign in…</p></main>;
  if (user.mustChangePassword) {
    return <FirstLoginPasswordPage onComplete={() => {
      setUser({ ...user, mustChangePassword: false });
      setPage('dashboard');
    }} />;
  }
  if (accessLoading) return <main className="auth-loading"><span className="auth-loading-mark">A</span><p>Verifying access…</p></main>;

  return <div className={`app-shell ${mobileMenu ? 'mobile-nav-open' : ''}`}>
    <Sidebar role={role} page={page} user={user} onNavigate={navigate} cartCount={cartCount} pendingCount={pendingCount} mobileMenu={mobileMenu} onClose={() => setMobileMenu(false)} onLogout={logout} />
    <main className="main-area"><header className="topbar"><div className="topbar-left"><button className="mobile-menu icon-button" aria-label="Open navigation" onClick={() => setMobileMenu(true)}><Icon name="menu" /></button><div className="breadcrumb"><span>Aquatica</span><i>/</i><b>{pageTitles[page]}</b></div></div>
      <div className="topbar-actions"><span className="workspace-role">{role === 'owner' ? 'Owner workspace' : 'Customer workspace'}</span><button className="icon-button notification-button" aria-label="Notifications" onClick={() => setPage(page === 'notifications' ? (role === 'owner' ? 'dashboard' : 'home') : 'notifications')}><Icon name="bell" size={18} />{unreadNotifications > 0 && <i />}</button><button className="top-avatar" aria-label={`Signed in as ${user.name}`}>{(user.name || 'A').slice(0, 1).toUpperCase()}</button></div>
    </header><div className="content-area">{selectedProduct ? <ProductDetails product={selectedProduct} onClose={() => setSelectedProduct(null)} onAdd={addToCart} /> : content}</div>
    <footer className="app-footer"><span>© 2026 Aquatica Nasugbu</span><span>Made for little pieces of the ocean <i>✳</i></span></footer></main>
    {toast && <div className="toast"><span className="toast-check"><Icon name="check" size={15} /></span>{toast}<button aria-label="Dismiss notification" onClick={() => setToast('')}><Icon name="close" size={15} /></button></div>}
    {modal && <AppModal modal={modal} onClose={() => setModal(null)} onRejectOpen={(order) => openPaymentReview(order, 'reject')} productForm={productForm} setProductForm={setProductForm} stockForm={stockForm} setStockForm={setStockForm} products={products} rejectReason={rejectReason} setRejectReason={setRejectReason} cancelReason={cancelReason} setCancelReason={setCancelReason} onSaveProduct={(event) => { event.preventDefault(); runOwnerAction(() => saveProduct(event)); }} onSaveStock={(event) => { event.preventDefault(); runOwnerAction(() => saveStock(event)); }} onReject={(order) => runOwnerAction(() => rejectPayment(order))} onApprove={(order) => runOwnerAction(() => approvePayment(order))} onCancel={(order) => cancelOrder(order, cancelReason)} />}
  </div>;
}

function ProductDetails({ product, onClose, onAdd }) {
  const [quantity, setQuantity] = useState(1);
  return <div className="product-detail-page"><button className="back-link" onClick={onClose}><Icon name="back" size={16} /> Back to shop</button><div className="product-detail-grid">
    <div className="product-detail-visual"><ProductImage product={product} /><span className="category-pill">{product.category}</span></div>
    <div className="product-detail-info"><div className="eyebrow">AQUATICA COLLECTION · {product.size}</div><h1>{product.name}</h1><div className="detail-price">{money(product.price)}</div><div className="detail-stock"><span className="stock-dot" /> {product.stock > 0 ? `${product.stock} available` : 'Currently sold out'}</div><p>{product.description}</p><div className="detail-divider" />
      <div className="care-note"><span>✳</span><div><b>A little note from us</b><span>Our team carefully checks every order. Send us a message if you need help finding the right fit for your tank.</span></div></div>
      <div className="detail-buy"><div className="quantity-control"><button aria-label="Decrease quantity" onClick={() => setQuantity(Math.max(1, quantity - 1))}>−</button><span>{quantity}</span><button aria-label="Increase quantity" onClick={() => setQuantity(Math.min(product.stock || 1, quantity + 1))}>+</button></div><Button disabled={!product.stock} onClick={() => { onAdd(product, quantity); onClose(); }}><Icon name="cart" size={17} /> Add to cart · {money(product.price * quantity)}</Button></div>
    </div>
  </div></div>;
}

function Confirmation({ icon, title, text, onOrders, onShop }) {
  return <div className="centered-state"><span className="success-icon"><Icon name={icon} size={24} /></span><div className="eyebrow">AQUATICA NASUGBU</div><h1>{title}</h1><p>{text}</p><div className="centered-actions"><Button onClick={onOrders}>View my orders <Icon name="arrow" size={16} /></Button><button className="text-button" onClick={onShop}>Continue shopping</button></div></div>;
}

function AppModal({ modal, onClose, onRejectOpen, productForm, setProductForm, stockForm, setStockForm, products, rejectReason, setRejectReason, cancelReason, setCancelReason, onSaveProduct, onSaveStock, onReject, onApprove, onConfirm, onReceived, onCancel, onStatus }) {
  const title = modal.type === 'order' ? `Order ${modal.order.id}` : {
    product: 'Add a product', stock: stockForm.reason === 'Adjustment' ? 'Adjust stock' : 'Restock product',
    reject: 'Reject payment proof', proof: 'Payment proof',
    cancel: 'Cancel this order?',
    'cancel-customer': 'Cancel this order?',
  }[modal.type];
  if (modal.type === 'cancel-customer' || modal.type === 'cancel') {
    return <Modal title="Cancel this order?" onClose={onClose}><div className="modal-form"><p className="modal-description">Cancel order <b>{modal.order.id}</b>? This action will be recorded in the order history.</p>{modal.type === 'cancel' && <Field label="Cancellation reason"><textarea className="input textarea" required value={cancelReason} onChange={(event) => setCancelReason(event.target.value)} /></Field>}<div className="modal-actions"><Button variant="secondary" onClick={onClose}>Keep order</Button><Button variant="danger" disabled={modal.type === 'cancel' && !cancelReason.trim()} onClick={() => onCancel(modal.order)}>Cancel order</Button></div></div></Modal>;
  }
  return <Modal title={title} onClose={onClose} wide={['order', 'proof'].includes(modal.type)}>
    {modal.type === 'product' && <form className="modal-form" onSubmit={onSaveProduct}><div className="form-grid">
      <Field label="Product name"><input className="input" autoFocus required value={productForm.name} onChange={(event) => setProductForm({ ...productForm, name: event.target.value })} /></Field>
      <Field label="Category"><select className="input" value={productForm.category} onChange={(event) => setProductForm({ ...productForm, category: event.target.value })}>{['Fish', 'Aquariums', 'Accessories', 'Plants'].map((item) => <option key={item}>{item}</option>)}</select></Field>
      <Field label="Price (₱)"><input className="input" required min="1" type="number" value={productForm.price} onChange={(event) => setProductForm({ ...productForm, price: event.target.value })} /></Field>
      <Field label="Opening stock"><input className="input" required min="0" type="number" value={productForm.stock} onChange={(event) => setProductForm({ ...productForm, stock: event.target.value })} /></Field>
      <Field label="Size or variant"><input className="input" placeholder="e.g. 2.5 in" value={productForm.size} onChange={(event) => setProductForm({ ...productForm, size: event.target.value })} /></Field>
      <Field label="Description" className="field-full"><textarea className="input textarea" value={productForm.description} onChange={(event) => setProductForm({ ...productForm, description: event.target.value })} /></Field>
    </div><div className="modal-actions"><Button type="button" variant="secondary" onClick={onClose}>Cancel</Button><Button type="submit">Add product</Button></div></form>}
    {modal.type === 'stock' && <form className="modal-form" onSubmit={onSaveStock}>
      <Field label="Product"><select className="input" required value={stockForm.productId} onChange={(event) => setStockForm({ ...stockForm, productId: event.target.value })}><option value="">Choose a product</option>{products.map((product) => <option key={product.id} value={product.id}>{product.name} · {product.stock} in stock</option>)}</select></Field>
      <div className="form-grid"><Field label="Movement"><select className="input" value={stockForm.reason} onChange={(event) => setStockForm({ ...stockForm, reason: event.target.value })}><option>Restock</option><option>Adjustment</option></select></Field><Field label={stockForm.reason === 'Adjustment' ? 'Units to remove' : 'Units to add'}><input className="input" type="number" min="1" required value={stockForm.quantity} onChange={(event) => setStockForm({ ...stockForm, quantity: event.target.value })} /></Field></div>
      <Field label="Reason or note (optional)"><input className="input" placeholder="e.g. Supplier delivery" value={stockForm.note} onChange={(event) => setStockForm({ ...stockForm, note: event.target.value })} /></Field>
      <div className="inline-info"><span className="info-mark">i</span><span>This change will be added to your stock movement history.</span></div><div className="modal-actions"><Button type="button" variant="secondary" onClick={onClose}>Cancel</Button><Button type="submit">Save movement</Button></div>
    </form>}
    {modal.type === 'reject' && <div className="modal-form"><p className="modal-description">Let {modal.order.customer} know what needs to be corrected. They can submit new payment proof once you reject this one.</p><Field label="Reason for rejection"><textarea className="input textarea" autoFocus placeholder="e.g. The amount on the screenshot doesn't match the order total." value={rejectReason} onChange={(event) => setRejectReason(event.target.value)} /></Field><div className="modal-actions"><Button variant="secondary" onClick={onClose}>Go back</Button><Button variant="danger" disabled={!rejectReason.trim()} onClick={() => onReject(modal.order)}>Reject payment proof</Button></div></div>}
    {modal.type === 'proof' && <div className="proof-modal-content"><div className="receipt-large proof-receipt">{modal.order.proofImageUrl ? <img className="proof-image" src={commercePath(modal.order.proofImageUrl)} alt={`Payment screenshot for ${modal.order.id}`} /> : <span>No payment screenshot is attached.</span>}</div><div className="proof-modal-info"><span className="eyebrow">CUSTOMER SUBMISSION</span><h3>{modal.order.customer}</h3><p>{modal.order.proofName || 'No screenshot attached'}</p><div className="detail-info-row"><span>Amount due</span><b>{money(modal.order.total)}</b></div><div className="detail-info-row"><span>GCash reference</span><b>{modal.order.reference || '—'}</b></div>{modal.order.paymentStatus === 'Under review' && <div className="verification-actions"><Button variant="danger-soft" onClick={() => onRejectOpen(modal.order)}>Reject</Button><Button onClick={() => onApprove(modal.order)}><Icon name="check" size={16} /> Approve</Button></div>}</div></div>}
    {modal.type === 'order' && <div className="owner-order-detail"><div className="owner-order-columns"><section className="detail-main"><div className="detail-status"><span>Order status</span><span className="status-label">{modal.order.status}</span><div className="step-track"><span className="step-done">Placed</span><i /><span>{modal.order.delivery === 'Pickup' ? 'Ready' : 'Preparing'}</span><i /><span>Completed</span></div></div><div className="detail-block"><h3>Items ordered</h3>{modal.order.items.map((item) => <div className="mini-line" key={item.productId}><span>{item.name} <i>× {item.quantity}</i></span><b>{money(item.price * item.quantity)}</b></div>)}</div><div className="detail-block"><h3>Customer details</h3><div className="detail-info-row"><span>Customer</span><b>{modal.order.customer}</b></div><div className="detail-info-row"><span>Phone</span><b>{modal.order.phone}</b></div><div className="detail-info-row"><span>{modal.order.delivery}</span><b>{modal.order.address}</b></div></div></section><aside className="owner-order-side"><div className="panel owner-summary"><h3>Payment summary</h3><div className="detail-info-row"><span>Total</span><b>{money(modal.order.total)}</b></div><div className="detail-info-row"><span>Method</span><b>{modal.order.method}</b></div><div className="detail-info-row"><span>Payment status</span><b>{modal.order.paymentStatus}</b></div></div><div className="owner-order-actions"><h3>Next step</h3>{modal.order.status === 'Pending' && modal.order.method !== 'GCash' && <Button className="button-full" onClick={() => onConfirm(modal.order)}>Confirm & deduct stock</Button>}{modal.order.method === 'GCash' && modal.order.paymentStatus === 'Under review' && <Button className="button-full" onClick={() => onApprove(modal.order)}>Approve payment</Button>}{modal.order.status === 'Preparing' && <Button variant="secondary" className="button-full" onClick={() => onStatus(modal.order, 'Ready')}>Mark as ready</Button>}{['Preparing', 'Ready'].includes(modal.order.status) && modal.order.paymentStatus !== 'Paid' && <Button className="button-full" onClick={() => onReceived(modal.order)}>Mark payment received</Button>}{['Preparing', 'Ready'].includes(modal.order.status) && modal.order.paymentStatus === 'Paid' && <Button className="button-full" onClick={() => onStatus(modal.order, 'Completed')}>Mark completed</Button>}{!['Completed', 'Cancelled'].includes(modal.order.status) && <Button variant="danger-soft" className="button-full" onClick={() => onRejectOpen({ ...modal.order, __cancel: true })}>Cancel order</Button>}</div></aside></div></div>}
  </Modal>;
}
